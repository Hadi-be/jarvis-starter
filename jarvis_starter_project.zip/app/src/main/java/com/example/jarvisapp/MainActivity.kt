package com.example.jarvisapp

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var jarvisText: TextView
    private lateinit var micBtn: ImageButton
    private lateinit var tts: TextToSpeech
    private val REQ_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        jarvisText = findViewById(R.id.jarvisText)
        micBtn = findViewById(R.id.micBtn)
        tts = TextToSpeech(this, this)

        // Jarvis Greeting
        speak("Assalamualaikum Hadi, Jarvis system activated.")

        micBtn.setOnClickListener {
            startVoiceInput()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.forLanguageTag("en-US")
        }
    }

    private fun speak(text: String) {
        jarvisText.text = text
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "JARVIS")
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolain...")
        startActivityForResult(intent, REQ_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CODE && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val command = result?.get(0)?.lowercase(Locale.getDefault()) ?: ""
            processCommand(command)
        }
    }

    private fun processCommand(command: String) {
        when {
            command.contains("hello") -> speak("Hello Hadi, how can I assist you?")
            command.contains("time") -> {
                val currentTime = Calendar.getInstance().time.toString()
                speak("The current time is $currentTime")
            }
            command.contains("open youtube") -> {
                val launchIntent = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                if (launchIntent != null) {
                    startActivity(launchIntent)
                    speak("Opening YouTube.")
                } else {
                    speak("YouTube is not installed.")
                }
            }
            else -> speak("Sorry, I did not understand that.")
        }
    }
}
